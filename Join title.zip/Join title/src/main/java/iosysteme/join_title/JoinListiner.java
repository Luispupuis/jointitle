package iosysteme.join_title;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class JoinListiner implements Listener {



  //  @EventHandler
  //  public void onJoin(PlayerJoinEvent e){
   //     Player p = e.getPlayer();
   //     p.sendTitle("§6§lINVSUCHT.NET", "§c§lInvsucht §f§lNetwork");
   //     e.setJoinMessage("");
 //   }
    
}
