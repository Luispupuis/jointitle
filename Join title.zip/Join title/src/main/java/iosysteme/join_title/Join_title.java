package iosysteme.join_title;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class Join_title extends JavaPlugin {


      public String title = this.getConfig().getString("jt.title");
    String subtitle = this.getConfig().getString("jt.subtitle");

    @Override
    public void onEnable() {
        // Plugin startup logic
        this.saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(new JoinListiner(), this);
    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
    public class JoinListiner implements Listener {



        @EventHandler
        public void onJoin(PlayerJoinEvent e){
            Player p = e.getPlayer();
            p.sendTitle(title, subtitle);
            e.setJoinMessage("");
        }
    }
}
